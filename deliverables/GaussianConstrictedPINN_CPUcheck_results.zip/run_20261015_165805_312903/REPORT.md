# Gaussian parcel PINN results

Preset: smoke. Carrier dimension: 2D. Runtime: 111.9 s.
Numerical verification: 7/10 passed. Literature validation: 0/51 run.
Research quality criteria met: False.

## Interpretation

All plotted solver fields and trajectories are PINN predictions. Analytical targets are independent reduced-model verification data. The catalogue audit records every literature case in its supplied order; no mismatched experiment is scored. A completed execution or an attractive figure does not establish predictive accuracy.

For 2D, parcels represent spherical populations moving in a plane. Forces and masses are converted to a per-depth convention using B/H. This is not the finite-size infinite-cylinder model. Extruded channel views solve no spanwise physics.

## Case diagnostics

| Case | Seed | Held-out NS RMS | Parcel ODE RMS | Max slip Re | Max α | Quality criteria |
|---|---:|---:|---:|---:|---:|---|
| low_inertia | 7 | 6.952 | 12.42 | 0.3144 | 0.0003062 | False |
| baseline | 7 | 6.739 | 4.984 | 0.4971 | 0.0003058 | False |
| high_loading | 7 | 7.043 | 4.988 | 0.4971 | 0.0009105 | False |
| high_inertia | 7 | 6.671 | 1.665 | 0.861 | 0.0003041 | False |

Acceptance is declared before training: all held-out residual RMS < 0.03, slip Re <= 1, local volume fraction < 0.01, all centers inside channel, trained checkpoint and no training error. Passing these screening criteria is necessary, not sufficient, for publication. Resolve residual, discretization and closure uncertainty.

## Remaining checks

- No experimental or resolved-body validation claimed.
- Regularized disturbed-velocity drag, no self-disturbance correction.
- Low slip Reynolds number required by Stokes drag; reported explicitly.
- No lubrication, lift, added mass, Basset history, particle rotation or finite-volume displacement.
- Soft contact is an optional physical-sphere closure; default parcel cases are collision-free.
- Residual thresholds are project criteria, not universal scientific accuracy.
- Paper preset and spatial/time/width/parcel refinement need separate completed runs.

## Figure captions

### Channel geometry

Original transient Gaussian-parcel problem with two added semicircular wall constrictions. Same periodic x boundary, body forcing, Stokes numbers, loadings and gravity.

![Channel geometry](figures/geometry.png)

### Coupled PINN

Two separate fully connected tanh networks, both with 2 hidden layers of width 16. Trainable outputs are coupled through normalized Gaussian quadrature; reference arrays are used only after training.

![Coupled PINN](figures/architecture.png)

### Stokes response

V01: independent reduced-model verification. Analytical targets were excluded from PINN training. Errors and acceptance criteria are in verification.json; a plot is not a pass verdict.

![Stokes response](validation/V01.png)

### Momentum exchange

V02: independent reduced-model verification. Analytical targets were excluded from PINN training. Errors and acceptance criteria are in verification.json; a plot is not a pass verdict.

![Momentum exchange](validation/V02.png)

### Gaussian overlap

V04: independent reduced-model verification. Analytical targets were excluded from PINN training. Errors and acceptance criteria are in verification.json; a plot is not a pass verdict.

![Gaussian overlap](validation/V04.png)

### Taylor–Green flow

V10: independent reduced-model verification. Analytical targets were excluded from PINN training. Errors and acceptance criteria are in verification.json; a plot is not a pass verdict.

![Taylor–Green flow](validation/V10.png)

### Verification overview

Pass/fail classifications are implementation checks using declared project tolerances. They do not certify the 51 literature benchmarks.

![Verification overview](figures/verification_overview.png)

### Training history

low_inertia: no smoothing or loss truncation beyond the positive logarithmic floor. Checkpoint uses minimum fixed-audit loss.

![Training history](cases/low_inertia_seed7/training.png)

### Flow fields

low_inertia: transient fluid and Gaussian volume fraction at t=1; only fluid-domain points are evaluated.

![Flow fields](cases/low_inertia_seed7/fields.png)

### Throat profile

Initial geometry-compatible field and final trained prediction at the throat. This is not a reference validation.

![Throat profile](cases/low_inertia_seed7/profile.png)

### Speed surface

Height encodes the speed of the 2D solution; this is not a third solved spatial direction.

![Speed surface](cases/low_inertia_seed7/speed_surface.png)

### Parcel transport

Actual time-dependent fluid and parcel PINN predictions, with periodic wrapping in x. Invalid solid penetration is reported, not corrected by projection.

![Parcel transport](cases/low_inertia_seed7/snapshots.png)

### Parcel paths

low_inertia: direct PINN parcel trajectories; open markers denote initial states and filled markers denote final states. No boundary clipping is applied.

![Parcel paths](cases/low_inertia_seed7/paths.png)

### Channel view

low_inertia: extruded illustration of a 2D solution; every particle has z=0. Display depth contains no solved physics.

![Channel view](cases/low_inertia_seed7/channel_view.png)

### Parcel velocities

low_inertia: PINN velocity outputs. Kinematic consistency with position derivatives is audited separately.

![Parcel velocities](cases/low_inertia_seed7/velocities.png)

### Conservation diagnostics

low_inertia: driven channel includes wall viscous and pressure tractions, body force and particle gravity. Total momentum and energy need not be constant. Quadrature errors enter global balances. Contact cases omit unsupported global balances.

![Conservation diagnostics](cases/low_inertia_seed7/budgets.png)

### Gaussian transport

Normalized Gaussian clouds follow the actual parcel network. The kernel is integrated only over fluid quadrature; width remains the original fixed filter width.

![Gaussian transport](cases/low_inertia_seed7/gaussian_snapshots.png)

### Parcel transport

low_inertia: actual predicted time evolution of the coupled fluid–Gaussian-parcel model. Red outlines flag centers inside solids; no clipping or artificial rebound is applied.

![Parcel transport](cases/low_inertia_seed7/transport.gif)

### Gaussian transport

low_inertia: actual predicted time evolution of the coupled fluid–Gaussian-parcel model. Red outlines flag centers inside solids; no clipping or artificial rebound is applied.

![Gaussian transport](cases/low_inertia_seed7/gaussian_transport.gif)

### Training history

baseline: no smoothing or loss truncation beyond the positive logarithmic floor. Checkpoint uses minimum fixed-audit loss.

![Training history](cases/baseline_seed7/training.png)

### Flow fields

baseline: transient fluid and Gaussian volume fraction at t=1; only fluid-domain points are evaluated.

![Flow fields](cases/baseline_seed7/fields.png)

### Throat profile

Initial geometry-compatible field and final trained prediction at the throat. This is not a reference validation.

![Throat profile](cases/baseline_seed7/profile.png)

### Speed surface

Height encodes the speed of the 2D solution; this is not a third solved spatial direction.

![Speed surface](cases/baseline_seed7/speed_surface.png)

### Parcel transport

Actual time-dependent fluid and parcel PINN predictions, with periodic wrapping in x. Invalid solid penetration is reported, not corrected by projection.

![Parcel transport](cases/baseline_seed7/snapshots.png)

### Parcel paths

baseline: direct PINN parcel trajectories; open markers denote initial states and filled markers denote final states. No boundary clipping is applied.

![Parcel paths](cases/baseline_seed7/paths.png)

### Channel view

baseline: extruded illustration of a 2D solution; every particle has z=0. Display depth contains no solved physics.

![Channel view](cases/baseline_seed7/channel_view.png)

### Parcel velocities

baseline: PINN velocity outputs. Kinematic consistency with position derivatives is audited separately.

![Parcel velocities](cases/baseline_seed7/velocities.png)

### Conservation diagnostics

baseline: driven channel includes wall viscous and pressure tractions, body force and particle gravity. Total momentum and energy need not be constant. Quadrature errors enter global balances. Contact cases omit unsupported global balances.

![Conservation diagnostics](cases/baseline_seed7/budgets.png)

### Gaussian transport

Normalized Gaussian clouds follow the actual parcel network. The kernel is integrated only over fluid quadrature; width remains the original fixed filter width.

![Gaussian transport](cases/baseline_seed7/gaussian_snapshots.png)

### Parcel transport

baseline: actual predicted time evolution of the coupled fluid–Gaussian-parcel model. Red outlines flag centers inside solids; no clipping or artificial rebound is applied.

![Parcel transport](cases/baseline_seed7/transport.gif)

### Gaussian transport

baseline: actual predicted time evolution of the coupled fluid–Gaussian-parcel model. Red outlines flag centers inside solids; no clipping or artificial rebound is applied.

![Gaussian transport](cases/baseline_seed7/gaussian_transport.gif)

### Training history

high_loading: no smoothing or loss truncation beyond the positive logarithmic floor. Checkpoint uses minimum fixed-audit loss.

![Training history](cases/high_loading_seed7/training.png)

### Flow fields

high_loading: transient fluid and Gaussian volume fraction at t=1; only fluid-domain points are evaluated.

![Flow fields](cases/high_loading_seed7/fields.png)

### Throat profile

Initial geometry-compatible field and final trained prediction at the throat. This is not a reference validation.

![Throat profile](cases/high_loading_seed7/profile.png)

### Speed surface

Height encodes the speed of the 2D solution; this is not a third solved spatial direction.

![Speed surface](cases/high_loading_seed7/speed_surface.png)

### Parcel transport

Actual time-dependent fluid and parcel PINN predictions, with periodic wrapping in x. Invalid solid penetration is reported, not corrected by projection.

![Parcel transport](cases/high_loading_seed7/snapshots.png)

### Parcel paths

high_loading: direct PINN parcel trajectories; open markers denote initial states and filled markers denote final states. No boundary clipping is applied.

![Parcel paths](cases/high_loading_seed7/paths.png)

### Channel view

high_loading: extruded illustration of a 2D solution; every particle has z=0. Display depth contains no solved physics.

![Channel view](cases/high_loading_seed7/channel_view.png)

### Parcel velocities

high_loading: PINN velocity outputs. Kinematic consistency with position derivatives is audited separately.

![Parcel velocities](cases/high_loading_seed7/velocities.png)

### Conservation diagnostics

high_loading: driven channel includes wall viscous and pressure tractions, body force and particle gravity. Total momentum and energy need not be constant. Quadrature errors enter global balances. Contact cases omit unsupported global balances.

![Conservation diagnostics](cases/high_loading_seed7/budgets.png)

### Gaussian transport

Normalized Gaussian clouds follow the actual parcel network. The kernel is integrated only over fluid quadrature; width remains the original fixed filter width.

![Gaussian transport](cases/high_loading_seed7/gaussian_snapshots.png)

### Parcel transport

high_loading: actual predicted time evolution of the coupled fluid–Gaussian-parcel model. Red outlines flag centers inside solids; no clipping or artificial rebound is applied.

![Parcel transport](cases/high_loading_seed7/transport.gif)

### Gaussian transport

high_loading: actual predicted time evolution of the coupled fluid–Gaussian-parcel model. Red outlines flag centers inside solids; no clipping or artificial rebound is applied.

![Gaussian transport](cases/high_loading_seed7/gaussian_transport.gif)

### Training history

high_inertia: no smoothing or loss truncation beyond the positive logarithmic floor. Checkpoint uses minimum fixed-audit loss.

![Training history](cases/high_inertia_seed7/training.png)

### Flow fields

high_inertia: transient fluid and Gaussian volume fraction at t=1; only fluid-domain points are evaluated.

![Flow fields](cases/high_inertia_seed7/fields.png)

### Throat profile

Initial geometry-compatible field and final trained prediction at the throat. This is not a reference validation.

![Throat profile](cases/high_inertia_seed7/profile.png)

### Speed surface

Height encodes the speed of the 2D solution; this is not a third solved spatial direction.

![Speed surface](cases/high_inertia_seed7/speed_surface.png)

### Parcel transport

Actual time-dependent fluid and parcel PINN predictions, with periodic wrapping in x. Invalid solid penetration is reported, not corrected by projection.

![Parcel transport](cases/high_inertia_seed7/snapshots.png)

### Parcel paths

high_inertia: direct PINN parcel trajectories; open markers denote initial states and filled markers denote final states. No boundary clipping is applied.

![Parcel paths](cases/high_inertia_seed7/paths.png)

### Channel view

high_inertia: extruded illustration of a 2D solution; every particle has z=0. Display depth contains no solved physics.

![Channel view](cases/high_inertia_seed7/channel_view.png)

### Parcel velocities

high_inertia: PINN velocity outputs. Kinematic consistency with position derivatives is audited separately.

![Parcel velocities](cases/high_inertia_seed7/velocities.png)

### Conservation diagnostics

high_inertia: driven channel includes wall viscous and pressure tractions, body force and particle gravity. Total momentum and energy need not be constant. Quadrature errors enter global balances. Contact cases omit unsupported global balances.

![Conservation diagnostics](cases/high_inertia_seed7/budgets.png)

### Gaussian transport

Normalized Gaussian clouds follow the actual parcel network. The kernel is integrated only over fluid quadrature; width remains the original fixed filter width.

![Gaussian transport](cases/high_inertia_seed7/gaussian_snapshots.png)

### Parcel transport

high_inertia: actual predicted time evolution of the coupled fluid–Gaussian-parcel model. Red outlines flag centers inside solids; no clipping or artificial rebound is applied.

![Parcel transport](cases/high_inertia_seed7/transport.gif)

### Gaussian transport

high_inertia: actual predicted time evolution of the coupled fluid–Gaussian-parcel model. Red outlines flag centers inside solids; no clipping or artificial rebound is applied.

![Gaussian transport](cases/high_inertia_seed7/gaussian_transport.gif)

### Parameter effects

Parcel-mean velocities by case. Multiple-seed shading, when present, is ±1 sample standard deviation; it is not a confidence bound or a discretization error estimate.

![Parameter effects](figures/parameter_effects.png)


## Geometry extension

Transient two-way Gaussian parcels; periodic x and original body forcing retained. Only the geometry and required wall/domain/initial-field treatment change. No new contact/rebound law: center penetration is penalized and explicitly reported. Initial velocity is adapted to the constriction; r=0 reproduces the original model exactly.
